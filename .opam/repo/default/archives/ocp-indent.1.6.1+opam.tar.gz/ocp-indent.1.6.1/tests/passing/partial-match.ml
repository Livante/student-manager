let () = match x with 
            | `A -> "A"
            | `B -> "B"
