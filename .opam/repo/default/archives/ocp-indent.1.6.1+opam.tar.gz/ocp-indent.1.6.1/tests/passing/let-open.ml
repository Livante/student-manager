
let _ =
  (* ... *)
  let open Option in
  indented_line
