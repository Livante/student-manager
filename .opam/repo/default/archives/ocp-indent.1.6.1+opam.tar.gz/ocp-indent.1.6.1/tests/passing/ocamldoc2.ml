a
  (* {[ (* {v *) ]} {v v} *)
  b

let _ =
  (*
     {[
       while true do
         xx
       done
       (* this is totally crazy !!! *)
     ]}
  *)
  ()
