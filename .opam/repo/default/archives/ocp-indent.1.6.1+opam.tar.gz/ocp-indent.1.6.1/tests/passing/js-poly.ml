let handle_query qs ~msg_client:_ =
  try_with (fun () ->
    if _ then
      f >>| fun () ->
      `Done ()
    else
      _
  )
;;

if _ then
  _
else
  assert_branch_has_node branch node >>| fun () ->
  { t with node; floating }
;;
