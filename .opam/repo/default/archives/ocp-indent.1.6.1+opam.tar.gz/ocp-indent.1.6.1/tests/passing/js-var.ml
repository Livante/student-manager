type t =
  | A
  | B of int
  | C
