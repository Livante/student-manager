module M : S with type a = b
              and type c = d
              and type e = f
;;
