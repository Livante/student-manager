type t = [ `aaa
         | `bbb
         | `ccc
         ]

type t = [ `aaa | `bbb
         | `ccc
         ]

type t =
  [ `aaa
  | `bbb
  | `ccc
  ]

type t =
  [ `aaa | `bbb
  | `ccc
  ]

type t =
  [
    `aaa
  | `bbb
  | `ccc
  ]

type t =
  [
    `aaa | `bbb
  | `ccc
  ]

type t = [
    `aaa
  | `bbb
  | `ccc
]

type t = [
    `aaa | `bbb
  | `ccc
]
