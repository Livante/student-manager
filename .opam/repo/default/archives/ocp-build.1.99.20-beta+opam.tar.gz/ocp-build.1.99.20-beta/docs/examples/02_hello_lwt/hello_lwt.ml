Lwt_main.run (Lwt_io.printf "Hello, world!\n")
