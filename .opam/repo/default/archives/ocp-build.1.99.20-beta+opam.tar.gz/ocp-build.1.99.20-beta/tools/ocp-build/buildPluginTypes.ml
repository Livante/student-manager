(**************************************************************************)
(*                                                                        *)
(*   Typerex Tools                                                        *)
(*                                                                        *)
(*   Copyright 2011-2017 OCamlPro SAS                                     *)
(*                                                                        *)
(*   All rights reserved.  This file is distributed under the terms of    *)
(*   the GNU General Public License version 3 described in the file       *)
(*   LICENSE.                                                             *)
(*                                                                        *)
(**************************************************************************)

open OcpCompat

(*
module type Package = sig

  val name : string

  val build_targets : unit -> BuildEngineTypes.build_file list
  val doc_targets : unit -> BuildEngineTypes.build_file list
  val test_targets : unit -> BuildEngineTypes.build_file list
  val test : (unit -> unit) option
end
*)
