type t = Constructor

exception MyError

type ext = ..

type ext += C1
