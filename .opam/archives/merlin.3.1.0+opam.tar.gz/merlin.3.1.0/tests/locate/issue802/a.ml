open Error

let f () = raise MyError

let g () = Constructor

let c : ext = C1
