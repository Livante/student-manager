let foo () = ()

let () =
  let foo () = () in
  foo ()
