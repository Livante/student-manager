type t = { foo : int }

let f t = t.foo

let foo () = 3

let f t = t.foo
