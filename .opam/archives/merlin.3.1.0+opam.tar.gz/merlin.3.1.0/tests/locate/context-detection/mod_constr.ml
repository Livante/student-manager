type t = String
let x = String.concat
